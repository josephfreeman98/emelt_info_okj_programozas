﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace BalkezesekLista
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader Olvas = new StreamReader("balkezesek.csv", Encoding.Default);
            List<string> Nev = new List<string>();
            List<string> Elso = new List<string>();
            List<string> Utolso = new List<string>();
            List<int> Suly = new List<int>();
            List<int> Magassag = new List<int>();
            string Fejlec = Olvas.ReadLine();
            while(!Olvas.EndOfStream)
            {
                string Sor = Olvas.ReadLine();
                string[] SorElemek = Sor.Split(';');
                Nev.Add(SorElemek[0]);
                Elso.Add(SorElemek[1]);
                Utolso.Add(SorElemek[2]);
                Suly.Add(Convert.ToInt32(SorElemek[3]));
                Magassag.Add(Convert.ToInt32(SorElemek[4]));
            }
            Olvas.Close();
            Console.WriteLine($"3. feladat: {Nev.Count}");
            //4. feladat 
            Console.WriteLine("4. feladat: ");
            for (int i = 0; i < Nev.Count; i++)
            {
                if (Utolso[i].Contains("1999-10-"))
                {
                    Console.WriteLine($"\t{Nev[i]}, {Math.Round((Magassag[i]*2.54),1)} cm");
                }
            }
            //5. feladat
            int AktEvszam=0;
            bool EvszamOK = false;
            while (EvszamOK == false)
            {
                
                Console.Write("Kérek egy 1990 és 1999 közötti évszámok!: ");
                AktEvszam = Convert.ToInt32(Console.ReadLine());
                if (AktEvszam >= 1990 && AktEvszam <= 1999)
                {
                    EvszamOK = true;
                }
                else 
                {
                    Console.Write("Hibás adat!");
                }
            }
            //6. feladat 
            double OsszSuly = 0;
            double Db = 0;
            for (int i = 0; i < Elso.Count; i++)
            {
                int ElsoEv = Convert.ToInt32(Elso[i].Split('-')[0]);
                int UtolsoEv = Convert.ToInt32(Utolso[i].Split('-')[0]);
                if (AktEvszam >= ElsoEv && AktEvszam <= UtolsoEv)
                {
                    OsszSuly += Suly[i];
                    Db++;
                }
            }
            Console.WriteLine($"6. feladat: {Math.Round((OsszSuly/Db),2)} font");
            Console.ReadLine();
        }
    }
}
