﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Kosar2004Lista
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> Hazai = new List<string>();
            List<string> Idegen = new List<string>();
            List<int> HazaiPont = new List<int>();
            List<int> IdegenPont = new List<int>();
            List<string> Helyszin = new List<string>();
            List<string> Idopont = new List<string>();

            StreamReader Olvas = new StreamReader("eredmenyek.csv",Encoding.Default);
            string Fejlec = Olvas.ReadLine();
            while(!Olvas.EndOfStream)
            {
                string Sor = Olvas.ReadLine();
                string[] SorElemek = Sor.Split(';');
                Hazai.Add(SorElemek[0]);
                Idegen.Add(SorElemek[1]);
                HazaiPont.Add(Convert.ToInt32(SorElemek[2]));
                IdegenPont.Add(Convert.ToInt32(SorElemek[3]));
                Helyszin.Add(SorElemek[4]);
                Idopont.Add(SorElemek[5]);
            }
            
            Olvas.Close();
            //3. feladat:
            int HazaiRealMerkozes = 0;
            int IdegenRealMerkozes = 0;
            for (int i = 0; i<Hazai.Count; i++)
            {
                if (Hazai[i].Contains("Real Madrid"))
                {
                    HazaiRealMerkozes++;
                }
                if (Idegen[i].Contains("Real Madrid"))
                {
                    IdegenRealMerkozes++;
                }
            }
            Console.WriteLine($"3. feladat: Real Madrid: Hazai: {HazaiRealMerkozes} Idegen: {IdegenRealMerkozes}");
            //4. feladat
            bool VoltEDontetlen = false;
            for(int i=0;i<HazaiPont.Count;i++)
            {
                if (HazaiPont[i] == IdegenPont[i])
                {
                    VoltEDontetlen = true;
                }
            }
            if(VoltEDontetlen==false)
            {
                Console.WriteLine("4. feladat: Volt döntetlen? nem");
            }
            else
            {
                Console.WriteLine("4. feladat: Volt döntetlen? igen");
            }
            string PontosNev = "";
            for (int i = 0; i < Hazai.Count; i++)
            {
                if (Hazai[i].Contains("Barcelona"))
                {
                    PontosNev = Hazai[i];
                }
            }
            Console.WriteLine("5. feladat: barcelonai csapat pontos neve: "+PontosNev);
            Console.WriteLine("6. feladat:");
            for (int i = 0; i < Idopont.Count; i++)
            {
                if (Idopont[i].Contains("2004-11-21"))
                {
                    Console.WriteLine($"\t{Hazai[i]}-{Idegen[i]} ({HazaiPont[i]}:{IdegenPont[i]})");
                }
            }
            Console.WriteLine("7. feladat:");
            List<string> Stadionok = new List<string>();
            for(int i=0;i<Helyszin.Count;i++)
            {
                bool SzerepelE = false;
                for (int j = 0; j < Stadionok.Count; j++)
                {
                    if (Helyszin[i] == Stadionok[j])
                    {
                        SzerepelE = true;
                    }
                }
                if (SzerepelE == false)
                {
                    Stadionok.Add(Helyszin[i]);
                }
            }
            int[] StadionokSeged = new int[Stadionok.Count];
            for (int i = 0; i < Helyszin.Count; i++)
            {
                for (int j = 0; j < Stadionok.Count; j++)
                {
                    if (Helyszin[i] == Stadionok[j])
                    {
                        StadionokSeged[j]++;
                    }
                }
            }
            for (int i = 0; i < StadionokSeged.Length; i++)
            {
                if (StadionokSeged[i] > 20)
                {
                    Console.WriteLine($"\t{Stadionok[i]}:{StadionokSeged[i]}");
                }
            }
            Console.ReadLine();

        }
    }
}
