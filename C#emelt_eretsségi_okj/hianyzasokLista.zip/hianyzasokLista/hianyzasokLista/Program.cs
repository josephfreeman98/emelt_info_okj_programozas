﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace hianyzasokLista
{
    class Program
    {
        static void Main(string[] args)
        {
            //1. feladat- Tárolja el a fájlok tartalmát olyan adatszerkezetben, amivel a további feladatok megoldhatók!
            StreamReader Olvas = new StreamReader("szeptember.csv", Encoding.Default);
            string Fejlec = Olvas.ReadLine();
            List<string> Nev = new List<string>();
            List<string> Osztaly = new List<string>();
            List<int> ElsoNap = new List<int>();
            List<int> UtolsoNap = new List<int>();
            List<int> MulasztottOrak = new List<int>();
            while (!Olvas.EndOfStream)
            {
                string Sor = Olvas.ReadLine();
                string[] SorElemek = Sor.Split(';');
                Nev.Add(SorElemek[0]);
                Osztaly.Add(SorElemek[1]);
                ElsoNap.Add(Convert.ToInt32(SorElemek[2]));
                UtolsoNap.Add(Convert.ToInt32(SorElemek[3]));
                MulasztottOrak.Add(Convert.ToInt32(SorElemek[4]));
            }
            Olvas.Close();
            //2. feladat - Határozza meg, és írja ki a képernyőre, hogy a diákok összesen hány órát mulasztottak ebben a hónapban.
            int OsszHianyzas = 0;
            for (int i = 0; i < MulasztottOrak.Count; i++)
            {
                OsszHianyzas += MulasztottOrak[i];
            }
            Console.WriteLine("2. feladat");
            Console.WriteLine($"\tÖsszes mulasztott órák száma: {OsszHianyzas} óra.");

            //3. feladat - Kérjen be a felhasználótól
            //egy napot 1 és 30 között
            //egy tanuló nevét
            Console.WriteLine("3. feladat");
            Console.Write("\tKérem adjon meg egy napot: ");
            int AdottNap = Convert.ToInt32(Console.ReadLine());
            Console.Write("\tTanuló neve: ");
            string AdottNev = Console.ReadLine();
            //4. feladat - Írja ki a képernyőre, hogy az előző feladatban beért tanulónak volt-e hiányzása! A „A tanuló hiányzott szeptemberben” vagy 
            //„A tanuló nem hiányzott szeptemberben” szöveget jelenítse meg
            bool HianyzottE = false;
            for (int i = 0; i < Nev.Count; i++)
            {
                if (Nev[i] == AdottNev)
                {
                    HianyzottE = true;
                }
            }
            Console.WriteLine("4. feladat");
            if (HianyzottE == false)
            {
                Console.WriteLine("\tA tanuló nem hiányzott szeptemberben");
            }
            else
            {
                Console.WriteLine("\tA tanuló hiányzott szeptemberben");
            }

            //5. feladat - Írja ki a képernyőre azon tanulók nevét és osztályát a minta szerint, akik a 3. feladatban bekért napon hiányoztak!
            //(Ha a 3.feladatot nem tudta megoldani, akkor a 19 - ei nappal dolgozzon!) Ha nem volt hiányzó, akkor a „Nem volt hiányzó” szöveget jelenítse meg!
            Console.WriteLine($"5.feladat: Hiányzók 2017.09.{AdottNap} - n:");
            bool VoltEHianyzo = false;
            for (int i = 0; i < ElsoNap.Count; i++)
            {
                if (ElsoNap[i] >= AdottNap && UtolsoNap[i] <= AdottNap)
                {
                    Console.WriteLine($"\t{Nev[i]} ({Osztaly[i]})");
                    VoltEHianyzo = true;
                }
            }
            if (VoltEHianyzo == false)
            {
                Console.WriteLine("Nem volt hiányzó");
            }
            //6. feladat - Készítsen összesítést, amely osztályonként fájlba írja a mulasztott órák számát! 
            //Az osszesites.csv nevű fájl tartalmazza az osztályt és a mulasztott órák számának összegét!
            List<string> Osztalyok = new List<string>();
            for (int i = 0; i < Osztaly.Count; i++)
            {
                bool SzerepelE = false;
                for (int j = 0; j < Osztalyok.Count; j++)
                {
                    if (Osztalyok[j] == Osztaly[i])
                    {
                        SzerepelE = true;
                    }
                }
                if (SzerepelE == false)
                {
                    Osztalyok.Add(Osztaly[i]);
                }
            }
            int[] OsztalyokSeged = new int[Osztalyok.Count];
            for (int i = 0; i < Osztaly.Count; i++)
            {
                for (int j = 0; j < Osztalyok.Count; j++)
                {
                    if (Osztalyok[j] == Osztaly[i])
                    {
                        OsztalyokSeged[j] += MulasztottOrak[i];
                    }
                }
            }
            StreamWriter Iro = new StreamWriter("osszesites.csv", false, Encoding.Default);
            for (int i = 0; i < Osztalyok.Count; i++)
            {
                Iro.WriteLine($"{Osztalyok[i]};{OsztalyokSeged[i]}");
            }
            Iro.Close();
            Console.ReadLine();
        }
    }
}
