﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.InteropServices;

//1. feladat- Készítsen programot a következő feladatok megoldására, amelynek a forráskódját kektura néven mentse el!
namespace kekturaLista
{
    class Program
    {
        //6. feladat - Készítsen logikai értékkel visszatérő függvényt (vagy jellemzőt) HianyosNev azonosítóval, melynek segítségével minősíteni tudja a túraszakaszok végpontjainak a nevét! 
        //Hiányos állomásneveknek minősítjük azokat a végpontneveket, melyek pecsételőhelyek, de a „pecsetelohely” karakterlánc nem található meg a nevükben. 
        //Ebben az esetben logikai igaz értékkel térjen vissza a függvény (vagy jellemző), egyébként pedig hamissal.
        static bool HianyosNev(string VizsgalandoNev)
        {
            //bool NemHianyos=false;
            if (VizsgalandoNev.Contains("pecsetelohely"))
            {
                return true;
                //NemHianyos=true;
            }
            else
            {
                return false;
                //NemHianyos=false;
            }
            //return NemHianyos;
        }
        static void Main(string[] args)
        {
            //2. feladat - Olvassa be a kektura.csv állományban lévő adatokat és tárolja el úgy, hogy a további feladatok megoldására alkalmas legyen! 
            //A fájlban legfeljebb 100 sor lehet!    
            StreamReader Olvas = new StreamReader("kektura.csv", Encoding.Default);
            int KezdoMagassag = Convert.ToInt32(Olvas.ReadLine());
            List<string> KiinduloPont = new List<string>();
            List<string> VegPont = new List<string>();
            List<double> Hossz = new List<double>();
            List<int> Emelkedes = new List<int>();
            List<int> Lejtes = new List<int>();
            List<char> PecseteloHely = new List<char>();
            while (!Olvas.EndOfStream)
            {
                string Sor = Olvas.ReadLine();
                string[] Sorelemek = Sor.Split(';');
                KiinduloPont.Add(Sorelemek[0]);
                VegPont.Add(Sorelemek[1]);
                Hossz.Add(Convert.ToDouble(Sorelemek[2]));
                Emelkedes.Add(Convert.ToInt32(Sorelemek[3]));
                Lejtes.Add(Convert.ToInt32(Sorelemek[4]));
                PecseteloHely.Add(Convert.ToChar(Sorelemek[5]));
            }
            Olvas.Close();
            //3. feladat - Határozza meg és írja ki a képernyőre a minta szerint, hogy hány szakasz található a kektura.csv állományban!
            Console.WriteLine($"3. feladat: Szakaszok száma {KiinduloPont.Count} db");
            //4. feladat - Határozza meg és írja ki a képernyőre a minta szerint, a túra teljes hosszát!
            double TeljesHossz = 0;
            for (int i = 0; i < Hossz.Count; i++)
            {
                TeljesHossz += Hossz[i];
            }
            Console.WriteLine($"A túra teljes hossza: {TeljesHossz} km");
            //5. feladat - Keresse meg és írja ki a képernyőre a túra legrövidebb szakaszának adatait a minta szerint!
            //Feltételezheti, hogy nincs két egyforma hosszúságú szakasz!
            int LegrovidebbIndex = 0;
            for (int i = 1; i < Hossz.Count; i++)
            {
                if (Hossz[i] < Hossz[LegrovidebbIndex])
                {
                    LegrovidebbIndex = i;
                }
            }
            Console.WriteLine("5. feladat: A legrövidebb szakasz adatai:");
            Console.WriteLine($"\tKezdete: {KiinduloPont[LegrovidebbIndex]}");
            Console.WriteLine($"\tVége: {VegPont[LegrovidebbIndex]}");
            Console.WriteLine($"\tTávolság: {Hossz[LegrovidebbIndex]}");
            //7. feladat - Keresse meg és írja ki a minta szerint a képernyőre a hiányos állomásneveket! 
            //Ha nincs hiányos állomásnév az adatokban, akkor a „Nincs hiányos állomásnév!” felirat jelenjen meg!
            Console.WriteLine("7. feladat: Hiányos állomásnevek:");
            for (int i = 0; i < VegPont.Count; i++)
            {
                if (PecseteloHely[i] == 'i' && HianyosNev(VegPont[i]) == false)
                {
                    Console.WriteLine($"\t{VegPont[i]}");
                }
            }
            //8. feladat - Ismerjük a túra kiindulópontjának tengerszint feletti magasságát és az egyes túraszakaszokon mért emelkedések és lejtések összegét. 
            //Az adatok ismeretében keressük meg a túra legmagasabban fekvő végpontját és határozzuk meg a végpont tengerszint feletti magasságát! 
            //Feltételezheti, hogy nincs kettő vagy több ilyen végpont!
            int LegmagasabbIndexe = 0;
            int LegMagasabb = KezdoMagassag;
            int AktMagassag = KezdoMagassag;
            for (int i = 0; i <Emelkedes.Count; i++)
            {
                AktMagassag += (Emelkedes[i] - Lejtes[i]);
                if (AktMagassag > LegMagasabb)
                {
                    LegMagasabb = AktMagassag;
                    LegmagasabbIndexe = i;
                }
            }
            Console.WriteLine("8. feladat: A túra legmagasabb fekvő végpontja:");
            Console.WriteLine("\tA végpont neve:" + VegPont[LegmagasabbIndexe]);
            Console.WriteLine($"\tA végpont tengerszint feletti magassága: {LegMagasabb} m");
            //9. feladat - Készítsen kektura2.csv néven szöveges állományt, mely szerkezete megegyezik a kektura.csv állományéval! 
            //A kimeneti fájl első sora a kiindulópont tengerszint feletti magasságát tartalmazza! 
            //A további sorokban a túra szakaszainak adatait írja ki! Azoknál a pecsételőhelyeknél, ahol nem található meg a végpont nevében a „pecsetelohely” 
            //karaktersorozat, ott kerüljön be a végpont nevének a végére egy szóközzel elválasztva a „pecsetelohely” szó!
            StreamWriter Iro = new StreamWriter("kektura2.csv", false, Encoding.Default);
            Iro.WriteLine(KezdoMagassag);
            for (int i = 0; i < KiinduloPont.Count; i++)
            {
                Iro.Write(KiinduloPont[i] + ";");
                if (HianyosNev(VegPont[i]) == false && PecseteloHely[i] == 'i')
                {
                    Iro.Write(VegPont[i] + " pecsetelohely;");

                }
                else
                {
                    Iro.Write(VegPont[i]+ ";");
                }
                Iro.WriteLine($"{Hossz[i]};{Emelkedes[i]};{Lejtes[i]};{PecseteloHely[i]}");
            }
            Iro.Close();

            Console.ReadLine();
        }
    }
}
