﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

//1. feladat - Készítsen programot a következő feladatok megoldására, amelynek a forráskódját helsinki1952 néven mentse el!
namespace helsinki1952Lista
{
    class Program
    {
        static void Main(string[] args)
        {
            //2. feladat - Olvassa be a helsinki.txt állományban lévő adatokat és tárolja el egy olyan adatszerkezetben, 
            //amely a további feladatok megoldására alkalmas!A fájlban legfeljebb 200 sor lehet.
            List<int> Helyezes = new List<int>();
            List<int> SportoloSzam = new List<int>();
            List<string> Sportag = new List<string>();
            List<string> Versenyszam = new List<string>();
            StreamReader Olvas = new StreamReader("helsinki.txt", Encoding.Default);
            while (!Olvas.EndOfStream)
            {
                string Sor = Olvas.ReadLine();
                string[] SorElemek = Sor.Split(' ');
                Helyezes.Add(Convert.ToInt32(SorElemek[0]));
                SportoloSzam.Add(Convert.ToInt32(SorElemek[1]));
                Sportag.Add(SorElemek[2]);
                Versenyszam.Add(SorElemek[3]);
            }
            Olvas.Close();
            //3. feladat - Határozza meg és írja ki a képernyőre a minta szerint, hogy hány pontszerző helyezést értek el a magyar olimpikonok!
            Console.WriteLine("3. feladat:");
            Console.WriteLine("Pontszerző helyezések száma: "+Helyezes.Count);
            //4. feladat - Készítsen statisztikát a megszerzett érmek számáról, majd összesítse az érmek számát a minta szerint!
            int Arany = 0;
            int Ezust = 0;
            int Bronz = 0;
            for (int i = 0; i<Helyezes.Count; i++)
            {
                if (Helyezes[i] == 1)
                {
                    Arany++;
                }
                else if (Helyezes[i] == 2)
                {
                    Ezust++;
                }
                else if (Helyezes[i] == 3)
                {
                    Bronz++;
                }
                else { }
            }
            Console.WriteLine("4. feladat:");
            Console.WriteLine("Arany: "+Arany);
            Console.WriteLine("Ezüst: "+Ezust);
            Console.WriteLine("Bronz: "+Bronz);
            Console.WriteLine("Összesen: "+(Arany+Ezust+Bronz));
            //5. feladat -Az olimpián az országokat az elért eredményeik alapján rangsorolják. Az 1−6.helyezéseket olimpiai pontokra váltják, 
            //és ezt összegzik. Határozza meg és írja ki a minta szerint az elért olimpiai pontok összegét az alábbi táblázat segítségével!
            int Osszpontszam = 0;
            for (int i = 0; i < Helyezes.Count; i++)
            {
                if (Helyezes[i] == 1)
                {
                    Osszpontszam += 7;//Osszpontszam=Osszpontszam+7;
                }
                else if (Helyezes[i] == 2)
                {
                    Osszpontszam += 5;//Osszpontszam=Osszpontszam+5;
                }
                else if (Helyezes[i] == 3)
                {
                    Osszpontszam += 4;//Osszpontszam=Osszpontszam+4;
                }
                else if (Helyezes[i] == 4)
                {
                    Osszpontszam += 3;//Osszpontszam=Osszpontszam+3;
                }
                else if (Helyezes[i] == 5)
                {
                    Osszpontszam += 2;//Osszpontszam=Osszpontszam+2;
                }
                else if (Helyezes[i] == 6)
                {
                    Osszpontszam += 1;//Osszpontszam=Osszpontszam+1;
                }
                else { }
            }
            Console.WriteLine("5. feladat:");
            Console.WriteLine("Olimpiai pontok száma: "+Osszpontszam);

            //6. feladat - Az úszás és a torna sportágakban világversenyeken mindig jól szerepeltek a magyar sportolók.Határozza meg és írja ki a minta szerint, hogy az 1952 - es nyári olimpián melyik
            //sportágban szereztek több érmet a sportolók! Ha az érmek száma egyenlő, akkor az „Egyenlő volt az érmek száma” felirat jelenjen meg!
            int Uszas = 0;
            int Torna = 0;
            for (int i = 0; i < Helyezes.Count; i++)
            {
                if (Helyezes[i] < 4 && Sportag[i] == "uszas")
                {
                    Uszas++;
                }
                else if (Helyezes[i] < 4 && Sportag[i] == "torna")
                {
                    Torna++;
                }
            }
            Console.WriteLine("6. feladat:");
            if (Uszas > Torna)
            {
                Console.WriteLine("Úszás sportágban szereztek több érmet");
            }
            else if (Uszas < Torna)
            {
                Console.WriteLine("Torna sportágban szereztek több érmet");
            }
            else
            {
                Console.WriteLine("Egyenlő volt az érmek száma");
            }
            //7. feladat - A helsinki.txt állományba hibásan, egybeírva „kajakkenu” került a kajak-kenu sportág neve. 
            //Készítsen szöveges állományt helsinki2.txt néven, amelybe helyesen, kötőjellel kerül a sportág neve! 
            //Az új állomány tartalmazzon minden helyezést a forrásállományból, a sportágak neve elé kerüljön be a megszerzett 
            //olimpiai pont is a minta szerint! A sorokban az adatokat szóközzel válassza el egymástól!
            for (int i = 0; i < Sportag.Count; i++)
            {
                if (Sportag[i] == "kajakkenu")
                {
                    Sportag[i] = "kajak-kenu";
                }
            }
            StreamWriter Iro = new StreamWriter("helsinki2.txt", false, Encoding.Default);
            for (int i = 0; i < Helyezes.Count; i ++)
            {
                Iro.Write(Helyezes[i] + " ");
                Iro.Write(SportoloSzam[i] + " ");
                if (Helyezes[i] == 1)
                {
                    Iro.Write("7 ");
                }
                else if (Helyezes[i] == 2)
                {
                    Iro.Write("5 ");
                }
                else if (Helyezes[i] == 3)
                {
                    Iro.Write("4 ");
                }
                else if (Helyezes[i] == 4)
                {
                    Iro.Write("3 ");
                }
                else if (Helyezes[i] == 5)
                {
                    Iro.Write("2 ");
                }
                else if (Helyezes[i] == 6)
                {
                    Iro.Write("1 ");
                }
                else { }
                Iro.Write(Sportag[i] + " ");
                Iro.WriteLine(Versenyszam[i] + " ");
                //Iro.WriteLine(Sportag[i]+" "+Versenyszam[i] + " ");
            }
            Iro.Close();
            //8. feladat -Határozza meg, hogy melyik pontszerző helyezéshez fűződik a legtöbb sportoló! Írja ki a minta szerint a helyezést, a sportágat, a versenyszámot
            //és a sportolók számát! Feltételezheti, hogy nem alakult ki holtverseny.
            int MaxCsapatIndexe = 0;
            for (int i = 1; i < SportoloSzam.Count; i++)
            {
                if (SportoloSzam[i] > SportoloSzam[MaxCsapatIndexe])
                {
                    MaxCsapatIndexe = i;
                }
            }
            Console.WriteLine("8.feladat:");
            Console.WriteLine("Helyezés: "+Helyezes[MaxCsapatIndexe]);
            Console.WriteLine("Sportág: "+Sportag[MaxCsapatIndexe]);
            Console.WriteLine("Versenyszám: "+Versenyszam[MaxCsapatIndexe]);
            Console.WriteLine("Sportolók száma: "+SportoloSzam[MaxCsapatIndexe]);

            Console.ReadLine();
        }
    }
}
