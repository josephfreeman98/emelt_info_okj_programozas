﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FIFAvilagranglista
{
    class Program
    {
        static void Main(string[] args)
        {
            //Csapat; Helyezes; Valtozas; Pontszam
            List<string> Csapat = new List<string>();
            List<int> Helyezes = new List<int>();
            List<int> Valtozas = new List<int>();
            List<int> Pontszam = new List<int>();

            StreamReader Olvas = new StreamReader("fifa.txt", Encoding.Default);
            string Fejlec = Olvas.ReadLine();
            while (!Olvas.EndOfStream)
            {
                string Sor = Olvas.ReadLine();
                string[] SorElemek = Sor.Split(';');
                Csapat.Add(SorElemek[0]);
                Helyezes.Add(Convert.ToInt32(SorElemek[1]));
                Valtozas.Add(Convert.ToInt32(SorElemek[2]));
                Pontszam.Add(Convert.ToInt32(SorElemek[3]));
            }
            Olvas.Close();
            Console.WriteLine($"3. feladat: A világranglistán {Csapat.Count} csapat szerepel");
            //4. feladat
            double Osszpontszam = 0;
            for(int i=0;i<Pontszam.Count;i++)
            {
                Osszpontszam += Pontszam[i];    
            }
            Console.WriteLine($"4. feladat: A csapatok átlagos pontszáma: {Math.Round(Osszpontszam/Pontszam.Count,2)} pont");
            //5. feladat
            int MaximumValtozasIndex = 0;
            for (int i = 1; i < Valtozas.Count; i++)
            {
                if (Valtozas[i] > Valtozas[MaximumValtozasIndex])
                {
                    MaximumValtozasIndex = i;
                }
            }
            Console.WriteLine("5. feladat: A legtöbbet javító csapat");
            Console.WriteLine("\tHelyezés: "+Helyezes[MaximumValtozasIndex]);
            Console.WriteLine("\tCsapat: "+Csapat[MaximumValtozasIndex]);
            Console.WriteLine("\tPontszám: "+Pontszam[MaximumValtozasIndex]);
            //6. feladat
            bool VanEMagyarorszag = false;
            for (int i = 0; i < Csapat.Count; i++)
            {
                if (Csapat[i].Contains("Magyar"))
                {
                    VanEMagyarorszag = true;
                }
            }
            if (VanEMagyarorszag == true)
            {
                Console.WriteLine("A csapatok között van Magyarország");
            }
            else
            {
                Console.WriteLine("A csapatok között nincs Magyarország");
            }
            //7. feladat
            List<int> ValtozasLista = new List<int>();
            for (int i = 0; i < Valtozas.Count; i++)
            {
                bool SzerepelE = false;
                for (int j = 0; j < ValtozasLista.Count; j++)
                {
                    if (ValtozasLista[j] == Valtozas[i])
                    {
                        SzerepelE = true;
                    }
                }
                if (SzerepelE == false)
                {
                    ValtozasLista.Add(Valtozas[i]);
                }
            }
            int[] ValtozasListaSeged = new int[ValtozasLista.Count];
            for (int i = 0; i < Valtozas.Count; i++)
            {
                for (int j = 0; j < ValtozasLista.Count; j++)
                {
                    if (ValtozasLista[j] == Valtozas[i])
                    {
                        ValtozasListaSeged[j]++;
                    }
                }
            }
            Console.WriteLine("7. feladat: Statisztika:");
            for (int i = 0; i < ValtozasLista.Count; i++)
            {
                if (ValtozasListaSeged[i] > 1)
                {
                    Console.WriteLine($"\t{ValtozasLista[i]} helyet változtatott: {ValtozasListaSeged[i]} csapat");
                }
            }
            Console.ReadLine();
        }
    }
}
