﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace NobelLista
{
    class Program
    {
        static void Main(string[] args)
        {
            //2. feladat
            List<int> Evszam = new List<int>();
            List<string> Tipus = new List<string>();
            List<string> KeresztNev = new List<string>();
            List<string> VezNev = new List<string>();
            StreamReader Olvas = new StreamReader("nobel.csv", Encoding.Default);
            string Fejlec = Olvas.ReadLine();
            while (!Olvas.EndOfStream)
            {
                string Sor = Olvas.ReadLine();
                string[] SorElemek = Sor.Split(';');
                Evszam.Add(Convert.ToInt32(SorElemek[0]));
                Tipus.Add(SorElemek[1]);
                KeresztNev.Add(SorElemek[2]);
                VezNev.Add(SorElemek[3]);
            }
            Olvas.Close();
            //3. feladat
            for (int i = 0; i < KeresztNev.Count; i++)
            {
                if (KeresztNev[i] == "Arthur B.")
                {
                    Console.WriteLine("3. feladat: "+Tipus[i]);
                }
            }
            //4. feladat
            for (int i = 0; i < KeresztNev.Count; i++)
            {
                if (Tipus[i] == "irodalmi" && Evszam[i]==2017)
                {
                    Console.WriteLine("4. feladat: " + KeresztNev[i]+ " " + VezNev[i]);
                }
            }
            //5. feladat
            Console.WriteLine("5. feladat: ");
            for (int i = 0; i < VezNev.Count; i++)
            {
                if (VezNev[i] == "" && Tipus[i] == "béke" && Evszam[i] >= 1990)
                {
                    Console.WriteLine($"\t{Evszam[i]}: {KeresztNev[i]}");
                }
            }
            //6. feladat
            Console.WriteLine("6. feladat");
            for (int i = 0; i < VezNev.Count; i++)
            {
                if (VezNev[i].Contains("Curie"))
                {
                    Console.WriteLine($"\t{Evszam[i]}: {KeresztNev[i]} {VezNev[i]} ({Tipus[i]})");
                }
            }
            //7. feladat - TESCO gazdaságos megoldás
            int fizikai = 0;
            int kemiai = 0;
            int orvosi = 0;
            int irodalmi = 0;
            int beke = 0;
            int kozg = 0;
            for (int i = 0; i < Tipus.Count; i++)
            {
                if (Tipus[i] == "fizikai")
                {
                    fizikai++;
                }
                else if (Tipus[i] == "kémiai")
                {
                    kemiai++;
                }
                else if (Tipus[i] == "orvosi")
                {
                    orvosi++;
                }
                else if (Tipus[i] == "irodalmi")
                {
                    irodalmi++;
                }
                else if (Tipus[i] == "béke")
                {
                    beke++;
                }
                else if (Tipus[i] == "közgazdaságtani")
                {
                    kozg++;
                }
            }
            Console.WriteLine("7. feladat:");
            Console.WriteLine($"\tfizikai\t\t\t{fizikai} db");
            Console.WriteLine($"\tkémiai\t\t\t{kemiai} db");
            Console.WriteLine($"\torvosi\t\t\t{orvosi} db");
            Console.WriteLine($"\tirodalmi\t\t{irodalmi} db");
            Console.WriteLine($"\tbéke\t\t\t{beke} db");
            Console.WriteLine($"\tközgazdaságtani\t\t{kozg} db");
            //7. feladat - Alternatív (helyes) megoldás
            List<string> DijTipusok = new List<string>();
            for (int i = 0; i < Tipus.Count; i++)
            {
                bool SzerepelE = false;
                for(int j=0;j<DijTipusok.Count;j++)
                {
                    if (Tipus[i] == DijTipusok[j])
                    {
                        SzerepelE = true;
                    }
                }
                if (SzerepelE == false)
                {
                    DijTipusok.Add(Tipus[i]);
                }
            }
            int[] DijTipusokSeged = new int[DijTipusok.Count];
            for (int i = 0; i < Tipus.Count; i++)
            {
                for (int j = 0; j < DijTipusok.Count; j++)
                {
                    if (Tipus[i] == DijTipusok[j])
                    {
                        DijTipusokSeged[j]++;
                    }
                }
            }
            Console.WriteLine("7. feladat - Alternatív (HELYES) megoldás");
            for (int i = 0; i < DijTipusok.Count; i++)
            {
                Console.WriteLine("\t{0,-20} {1,6} db", DijTipusok[i], DijTipusokSeged[i]);
            }
            //8. feladat
            Console.WriteLine("8. feladat: orvosi.txt");
            StreamWriter Iro = new StreamWriter("orvosi.txt", false, Encoding.Default);
            for (int i = Tipus.Count-1; i > 0; i--)
            {
                if (Tipus[i] == "orvosi")
                {
                    Iro.WriteLine($"{Evszam[i]}:{KeresztNev[i]} {VezNev[i]}");
                }
            }
            Iro.Close();
            Console.ReadLine();
        }
    }
}
